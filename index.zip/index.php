<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Molexi Fortuna | Financial Education & Research</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary-color: #0A3D62;
            --secondary-color: #1E5F8B;
            --accent-color: #F5B041;
            --accent-gold: #D4AF37;
            --logo-brown: #8B4513;
            --light-color: #F8F9FA;
            --dark-color: #2C3E50;
            --success-color: #27AE60;
            --danger-color: #E74C3C;
            --text-color: #34495E;
            --border-color: #E2E8F0;
            --chart-line: #3498DB;
            --chart-bar: #2ECC71;
        }

        body {
            color: var(--text-color);
            line-height: 1.6;
            background-color: var(--light-color);
            overflow-x: hidden;
        }

        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px;
        }

        section {
            padding: 25px 0;
            position: relative;
        }

        h1,
        h2,
        h3,
        h4 {
            color: #143C46;
            margin-bottom: 1.2rem;
            font-weight: 700;
        }

        h1 {
            font-size: 3.2rem;
            line-height: 1.2;
            background: linear-gradient(45deg, var(--logo-brown), var(--accent-gold));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        h2 {
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 4rem;
            position: relative;
        }

        h2::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 120px;
            height: 4px;
            background: linear-gradient(to right, var(--accent-gold), var(--logo-brown));
            border-radius: 2px;
        }

        h3 {
            font-size: 1.8rem;
        }

        p {
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
            line-height: 1.8;
        }

        .btn {
            display: inline-block;
            background: linear-gradient(45deg, var(--accent-gold), var(--logo-brown));
            color: white;
            padding: 14px 35px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(139, 69, 19, 0.2);
        }

        .btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(139, 69, 19, 0.3);
        }

        .btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .btn:hover::after {
            left: 100%;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--accent-gold);
            color: var(--logo-brown);
        }

        .btn-outline:hover {
            background: linear-gradient(45deg, var(--accent-gold), var(--logo-brown));
            color: white;
        }

        /* Stock Market Background Animation */
        .market-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }

        .chart-line {
            position: absolute;
            width: 2px;
            background: linear-gradient(to bottom, transparent, var(--chart-line), transparent);
            animation: chartFloat 20s linear infinite;
        }

        .chart-bar {
            position: absolute;
            width: 4px;
            background: linear-gradient(to bottom, transparent, var(--chart-bar), transparent);
            animation: barRise 15s linear infinite;
        }

        @keyframes chartFloat {
            0% {
                transform: translateY(100vh) translateX(0);
                opacity: 0;
            }

            10% {
                opacity: 0.5;
            }

            90% {
                opacity: 0.5;
            }

            100% {
                transform: translateY(-100px) translateX(50px);
                opacity: 0;
            }
        }

        @keyframes barRise {
            0% {
                height: 0;
                opacity: 0;
            }

            10% {
                opacity: 1;
            }

            50% {
                height: 80px;
            }

            90% {
                opacity: 1;
            }

            100% {
                height: 0;
                opacity: 0;
            }
        }

        /* Header & Navigation */
        header {
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 5px 30px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            border-bottom: 3px solid var(--accent-gold);
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
            animation: logoPulse 3s infinite alternate;
        }

        @keyframes logoPulse {
            0% {
                transform: scale(1);
            }

            100% {
                transform: scale(1.05);
            }
        }

        .logo-img {
            height: 65px;
            width: auto;
            border-radius: 8px;
            filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1));
            transition: all 0.3s ease;
        }

        .logo-img:hover {
            transform: rotateY(15deg);
            filter: drop-shadow(0 6px 12px rgba(212, 175, 55, 0.3));
        }

        .logo-text {
            font-size: 2.2rem;
            font-weight: 800;
            background: linear-gradient(45deg, var(--logo-brown), var(--accent-gold));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-decoration: none;
            letter-spacing: 1px;
            position: relative;
        }

        .logo-text::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, var(--accent-gold), var(--logo-brown));
            border-radius: 2px;
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .logo-text:hover::after {
            transform: scaleX(1);
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav li {
            margin-left: 35px;
            position: relative;
        }

        nav a {
            text-decoration: none;
            color: #143C46;
            font-weight: 600;
            font-size: 1.1rem;
            transition: color 0.3s;
            position: relative;
        }

        nav a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 3px;
            background: linear-gradient(to right, var(--accent-gold), var(--logo-brown));
            transition: width 0.3s ease;
        }

        nav a:hover::after {
            width: 100%;
        }

        nav a:hover {
            color: var(--logo-brown);
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.8rem;
            color: var(--logo-brown);
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .mobile-menu-btn:hover {
            transform: rotate(90deg);
        }

        /* Hero Section with Advanced Typing Animation */
        .hero {
            background: linear-gradient(#143C46, #143C46), url('https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: white;
            text-align: center;
            padding: 90px 0 70px;
            /* top bottom reduced */
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(212, 175, 55, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(139, 69, 19, 0.1) 0%, transparent 50%);
        }

        .typing-container {
            position: relative;
            display: inline-block;
            margin-bottom: 40px;
        }

        .typing-text {
            color: white;
            font-size: 3.2rem;
            font-weight: 800;
            overflow: hidden;
            white-space: nowrap;
            margin: 0 auto;
            text-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        .cursor {
            display: inline-block;
            width: 3px;
            height: 3.5rem;
            background-color: var(--accent-gold);
            margin-left: 5px;
            animation: blink 1s infinite;
            vertical-align: middle;
        }

        @keyframes blink {

            0%,
            50% {
                opacity: 1;
            }

            51%,
            100% {
                opacity: 0;
            }
        }

        .hero p {
            font-size: 1.3rem;
            max-width: 850px;
            margin: 0 auto 60px;
            color: rgba(255, 255, 255, 0.95);
            text-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .hero-btns {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
            margin-top: 50px;
        }

        .hero .btn {
            margin: 0 15px;
            font-size: 1.1rem;
            padding: 16px 40px;
        }

        /* Animated Counter */
        .counter-section {
            background: linear-gradient(135deg, var(--light-color) 0%, #fff 100%);
            padding: 70px 0;
            border-top: 1px solid rgba(212, 175, 55, 0.2);
            border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        }

        .counter-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 30px;
            text-align: center;
        }

        .counter-item {
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border-top: 5px solid var(--accent-gold);
            transition: transform 0.4s ease, box-shadow 0.4s ease;
        }

        .counter-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(212, 175, 55, 0.15);
        }

        .counter-value {
            font-size: 3.5rem;
            font-weight: 800;
            color: var(--logo-brown);
            margin-bottom: 10px;
            font-family: 'Courier New', monospace;
        }

        .counter-label {
            color: var(--dark-color);
            font-weight: 600;
            font-size: 1.1rem;
        }

        /* About Section */
        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 70px;
            align-items: center;
        }

        .about-image {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
            position: relative;
            transform: perspective(1000px) rotateY(-5deg);
            transition: transform 0.6s ease;
        }

        .about-image:hover {
            transform: perspective(1000px) rotateY(0deg);
        }

        .about-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.6s ease;
        }

        .about-image:hover img {
            transform: scale(1.05);
        }

        .about-text h2 {
            text-align: left;
        }

        .about-text h2::after {
            left: 0;
            transform: none;
        }

        .values-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 30px;
            margin-top: 40px;
        }

        .value-item {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            border-left: 6px solid var(--accent-gold);
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .value-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(212, 175, 55, 0.15);
        }

        .value-item i {
            font-size: 2.5rem;
            color: var(--accent-gold);
            margin-bottom: 20px;
            display: inline-block;
            animation: iconFloat 3s ease-in-out infinite;
        }

        @keyframes iconFloat {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        /* Services Section */
        .services {
            background-color: #f8fafc;
            position: relative;
        }

        .services::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml,<svg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><path d="M54 54H6V6h48v48z" fill="none" stroke="%23D4AF37" stroke-width="0.5" stroke-dasharray="5,5"/></svg>');
            opacity: 0.05;
            z-index: 0;
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 40px;
            position: relative;
            z-index: 1;
        }

        .service-card {
            background-color: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08);
            transition: all 0.5s ease;
            position: relative;
            border: 1px solid rgba(212, 175, 55, 0.1);
        }

        .service-card:hover {
            transform: translateY(-15px) scale(1.03);
            box-shadow: 0 25px 50px rgba(212, 175, 55, 0.15);
        }

        .service-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(to right, var(--accent-gold), var(--logo-brown));
        }

        .service-icon {
            background: #143C46;
            color: white;
            font-size: 2.5rem;
            padding: 35px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .service-icon::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.1), transparent);
            transform: rotate(45deg);
            animation: shine 3s infinite;
        }

        @keyframes shine {
            0% {
                transform: translateX(-100%) rotate(45deg);
            }

            100% {
                transform: translateX(100%) rotate(45deg);
            }
        }

        .service-content {
            padding: 35px;
        }

        /* Why Choose Us */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 40px;
        }

        .feature-item {
            display: flex;
            align-items: flex-start;
            gap: 25px;
            background: white;
            padding: 35px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            transition: all 0.4s ease;
            border: 2px solid transparent;
        }

        .feature-item:hover {
            transform: translateX(10px);
            border-color: var(--accent-gold);
            box-shadow: 0 15px 40px rgba(212, 175, 55, 0.1);
        }

        .feature-icon {
            background: linear-gradient(135deg, var(--accent-gold), var(--logo-brown));
            color: white;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            flex-shrink: 0;
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .disclaimer-box {
            background: #F8FAFC;
            border-left: 6px solid #1B3E44;
            padding: 30px;
            color: #ff0000ff;
            margin-top: 50px;
            border-radius: 10px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px #1B3E44;
        }

        .disclaimer-box::before {

            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 2.5rem;
            opacity: 0.2;
        }

        /* Contact Section */
        .contact {
            background: linear-gradient(135deg, #f8fafc 0%, #fff 100%);
            position: relative;
        }

        .contact-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 70px;
        }

        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            gap: 20px;
            padding: 5px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            transition: all 0.4s ease;
        }

        .contact-item:hover {
            transform: translateX(10px);
            box-shadow: 0 15px 35px rgba(212, 175, 55, 0.1);
        }

        /* purana tha: .contact-item i { ... }  – isko change karo */
        .contact-item>i {
            background: linear-gradient(135deg, var(--accent-gold), var(--logo-brown));
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }

        .phone-line {
            margin: 2px 0;
            /* donon numbers ke beech ka gap kam */
            display: flex;
            align-items: center;
            gap: 6px;
            /* icon aur number ke beech thoda space */
            font-size: 1rem;
        }

        .phone-line i {
            background: none;
            /* yahan circle nahi chahiye */
            width: auto;
            height: auto;
            border-radius: 0;
            font-size: 0.95rem;
            color: var(--logo-brown);
        }


        .contact-form input,
        .contact-form textarea,
        .contact-form select {
            width: 100%;
            padding: 18px;
            margin-bottom: 25px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }

        .contact-form input:focus,
        .contact-form textarea:focus,
        .contact-form select:focus {
            outline: none;
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }

        .contact-form textarea {
            height: 180px;
            resize: vertical;
        }

        /* Stock Chart Animation */
        .stock-chart {
            width: 100%;
            height: 300px;
            margin: 40px 0;
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .chart-container {
            position: absolute;
            width: 100%;
            height: 100%;
            background: white;
        }

        .chart-line-animated {
            position: absolute;
            width: 100%;
            height: 2px;
            background: linear-gradient(to right, var(--chart-line), var(--accent-gold));
            bottom: 50px;
            animation: chartGrow 3s ease-out forwards;
        }

        @keyframes chartGrow {
            0% {
                width: 0;
                opacity: 0;
            }

            100% {
                width: 100%;
                opacity: 1;
            }
        }

        /* Footer */
        footer {
            background: #143C46;
            color: white;
            padding: 80px 0 40px;
            position: relative;
            overflow: hidden;
        }

        footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(to right, var(--accent-gold), var(--logo-brown));
        }

        .footer-top {
            display: flex;
            justify-content: center;
            margin-bottom: 50px;
        }

        .footer-logo-img {
            height: 90px;
            width: auto;
            border-radius: 10px;
            filter: drop-shadow(0 8px 15px rgba(0, 0, 0, 0.3));
            animation: logoFloat 4s ease-in-out infinite;
        }

        @keyframes logoFloat {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .footer-content {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 50px;
            margin-bottom: 50px;
        }

        .footer-logo {
            font-size: 2.2rem;
            font-weight: 800;
            color: white;
            margin-bottom: 20px;
            display: block;
            background: linear-gradient(45deg, white, var(--accent-gold));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .footer-column h4 {
            color: var(--accent-gold);
            margin-bottom: 25px;
            font-size: 1.3rem;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-column h4::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background: linear-gradient(to right, var(--accent-gold), transparent);
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column li {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-column a {
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-column a:hover {
            color: var(--accent-gold);
            transform: translateX(5px);
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .social-link {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }

        .social-link:hover {
            background: var(--accent-gold);
            transform: translateY(-5px);
        }

        .copyright {
            text-align: center;
            padding-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
        }

        /* Stock Ticker */
        .stock-ticker {
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 10px 0;
            overflow: hidden;
            position: relative;
            border-top: 3px solid var(--accent-gold);
            border-bottom: 3px solid var(--accent-gold);
        }

        .ticker-container {
            display: flex;
            animation: tickerScroll 40s linear infinite;
            white-space: nowrap;
        }

        .ticker-item {
            display: flex;
            align-items: center;
            margin-right: 60px;
            font-family: 'Courier New', monospace;
            font-weight: 600;
        }

        .ticker-symbol {
            color: var(--accent-gold);
            font-weight: 700;
            margin-right: 10px;
            font-size: 1.2rem;
        }

        .ticker-price {
            margin-right: 20px;
            font-size: 1.1rem;
        }

        .ticker-change {
            padding: 3px 10px;
            border-radius: 4px;
            font-weight: 700;
        }

        .ticker-change.positive {
            background-color: rgba(39, 174, 96, 0.2);
            color: #27AE60;
        }

        .ticker-change.negative {
            background-color: rgba(231, 76, 60, 0.2);
            color: #E74C3C;
        }

        @keyframes tickerScroll {
            0% {
                transform: translateX(0);
            }

            100% {
                transform: translateX(-50%);
            }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .container {
                max-width: 95%;
            }

            h1 {
                font-size: 2.8rem;
            }

            .typing-text {
                font-size: 2.8rem;
            }
        }

        @media (max-width: 992px) {

            .about-content,
            .features-grid,
            .contact-container,
            .footer-content {
                grid-template-columns: 1fr;
            }

            .services-grid,
            .counter-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .typing-text {
                font-size: 2.4rem;
            }

            h1 {
                font-size: 2.5rem;
            }

            h2 {
                font-size: 2rem;
            }

            .hero {
                padding: 110px 0 60px;
            }

            .hero-btns {
                flex-direction: column;
                align-items: center;
            }

            .hero-btns .btn {
                margin-bottom: 20px;
                width: 80%;
                max-width: 350px;
            }
        }

        @media (max-width: 768px) {

            .services-grid,
            .counter-grid,
            .values-grid {
                grid-template-columns: 1fr;
            }

            .mobile-menu-btn {
                display: block;
            }

            nav {
                position: fixed;
                top: 100px;
                left: 0;
                width: 100%;
                background-color: white;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
                padding: 30px;
                transform: translateX(-100%);
                transition: transform 0.5s ease;
                z-index: 999;
                border-radius: 0 0 20px 20px;
            }

            nav.active {
                transform: translateX(0);
            }

            nav ul {
                flex-direction: column;
            }

            nav li {
                margin: 0 0 25px 0;
            }

            .logo-img {
                height: 55px;
            }

            .logo-text {
                font-size: 1.8rem;
            }

            .header-container {
                padding: 12px 0;
            }

            .hero {
                margin-top: 0;
                /* ✅ REMOVE EXTRA GAP */
                padding: 85px 15px 50px;
                /* ✅ PERFECT MOBILE HERO HEIGHT */
            }

            .typing-text {
                font-size: 2rem;
                white-space: normal;
            }

            .cursor {
                display: none;
            }

            .footer-logo-img {
                height: 70px;
            }

            section {
                padding: 80px 0;
            }
        }

        @media (max-width: 576px) {
            h1 {
                font-size: 2rem;
            }

            h2 {
                font-size: 1.8rem;
            }

            .typing-text {
                font-size: 1.7rem;
            }

            .hero {
                padding: 75px 15px 45px;
                /* ✅ NO EXTRA WHITE SPACE */
            }

            .container {
                padding: 0 20px;
            }

            .counter-value {
                font-size: 2.8rem;
            }

            .btn {
                padding: 12px 30px;
                font-size: 1rem;
            }

            .logo-img {
                height: 50px;
            }

            .logo-text {
                font-size: 1.6rem;
            }

            .footer-content {
                grid-template-columns: 1fr;
                gap: 40px;
            }
        }

        .head {
            color: #ffffffff;
        }

        @media (max-width: 576px) {
            .feature-item {
                flex-direction: row;
                padding: 20px;
                /* ✅ Smaller padding */
                gap: 15px;
                /* ✅ Tighter spacing */
            }

            .feature-icon {
                width: 50px;
                /* ✅ Smaller icon */
                height: 50px;
                font-size: 1.3rem;
            }

            .feature-text h3 {
                font-size: 1.1rem;
                /* ✅ Smaller heading */
                margin-bottom: 6px;
            }

            .feature-text p {
                font-size: 0.95rem;
                /* ✅ Better mobile text */
                line-height: 1.5;
            }
        }

        /* ✅ FIX CONTACT SECTION LAYOUT (ALL DEVICES) */

        .contact-info h3 {
            margin-bottom: 10px;
        }

        .contact-info>p {
            margin-bottom: 25px;
            font-size: 1rem;
            line-height: 1.6;
        }

        /* ✅ Contact card clean design */
        .contact-item {
            align-items: center;
            /* vertical center */
            padding: 18px 20px;
            /* ✅ balanced padding */
            gap: 15px;
            /* ✅ tighter spacing */
            border-radius: 14px;
        }

        /* ✅ Icon circle fix */
        .contact-item>i {
            width: 44px;
            height: 44px;
            font-size: 1.1rem;
        }

        /* ✅ Contact text fix */
        .contact-item h4 {
            margin-bottom: 5px;
            font-size: 1.05rem;
        }

        .contact-item p {
            margin-bottom: 0;
            font-size: 0.95rem;
            line-height: 1.5;
        }

        /* ✅ Phone numbers alignment */
        .phone-line {
            font-size: 0.95rem;
            gap: 8px;
        }

        .phone-line i {
            font-size: 0.95rem;
        }

        /* ✅ MOBILE FIX */
        @media (max-width: 576px) {
            .contact-container {
                gap: 35px;
                /* ✅ reduce large gap */
            }

            .contact-item {
                padding: 15px 16px;
            }

            .contact-item>i {
                width: 38px;
                height: 38px;
                font-size: 1rem;
            }

            .contact-item h4 {
                font-size: 1rem;
            }

            .contact-item p {
                font-size: 0.92rem;
            }
        }
    </style>
</head>

<body>
    <!-- Stock Market Background Animation -->
    <!-- <div class="market-bg" id="marketBg"></div> -->

    <!-- Stock Ticker -->
    <div class="stock-ticker">
        <div class="ticker-container">
            <div class="ticker-item">
                <span class="ticker-symbol">NIFTY50</span>
                <span class="ticker-price">₹22,415.80</span>
                <span class="ticker-change positive">+0.85%</span>
            </div>
            <div class="ticker-item">
                <span class="ticker-symbol">SENSEX</span>
                <span class="ticker-price">₹73,895.54</span>
                <span class="ticker-change positive">+0.72%</span>
            </div>
            <div class="ticker-item">
                <span class="ticker-symbol">BANKNIFTY</span>
                <span class="ticker-price">₹48,230.15</span>
                <span class="ticker-change negative">-0.35%</span>
            </div>
            <div class="ticker-item">
                <span class="ticker-symbol">GOLD</span>
                <span class="ticker-price">₹6,420/g</span>
                <span class="ticker-change positive">+1.2%</span>
            </div>
            <div class="ticker-item">
                <span class="ticker-symbol">USD/INR</span>
                <span class="ticker-price">₹83.45</span>
                <span class="ticker-change positive">+0.15%</span>
            </div>
        </div>
    </div>

    <!-- Header & Navigation -->
    <header>
        <div class="container header-container">
            <div class="logo-container">
                <img src="https://ik.imagekit.io/digirank/WhatsApp%20Image%202025-11-26%20at%206.26.43%20PM.jpeg"
                    alt="Molexi Fortuna Logo" class="logo-img">
                <a href="#" class="logo-text">Molexi Fortuna</a>
            </div>
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <nav id="mainNav">
                <ul>
                    <li><a href="#home"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="#about"><i class="fas fa-info-circle"></i> About</a></li>
                    <li><a href="#services"><i class="fas fa-briefcase"></i> Our Services</a></li>
                    <li><a href="#why-choose"><i class="fas fa-star"></i> Why Choose Us</a></li>
                    <li><a href="#contact"><i class="fas fa-envelope"></i> Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="container">
            <!-- <div class="typing-container"> -->
            <h1 class="head">Empowering Financial Awareness Through Research & Education</h1>
            <!-- <span class="cursor"></span> -->
        </div>
        <p>Learn with clarity. Understand financial markets responsibly. Molexi Fortuna Private Limited is a financial
            research and market education company committed to promoting responsible financial awareness.</p>
        <div class="hero-btns">
            <a href="#services" class="btn"><i class="fas fa-chart-line"></i> Explore Our Programs</a>
            <a href="#contact" class="btn btn-outline"><i class="fas fa-phone-alt"></i> Get In Touch</a>
        </div>
        </div>
    </section>

    <!-- Animated Counter -->
    <section class="counter-section">
        <div class="container">
            <div class="counter-grid">
                <div class="counter-item">
                    <div class="counter-value" data-count="5000">5000</div>
                    <div class="counter-label">Students Educated</div>
                </div>
                <div class="counter-item">
                    <div class="counter-value" data-count="150">150</div>
                    <div class="counter-label">Webinars Conducted</div>
                </div>
                <div class="counter-item">
                    <div class="counter-value" data-count="98">98</div>
                    <div class="counter-label">Client Satisfaction</div>
                </div>
                <div class="counter-item">
                    <div class="counter-value" data-count="5">5</div>
                    <div class="counter-label">Years Experience</div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>Who We Are</h2>
                    <p>Molexi Fortuna is dedicated to simplifying financial learning and empowering individuals through
                        ethical and unbiased information.</p>
                    <p>Molexi Fortuna Private Limited is a registered financial research and market education company
                        based in Bhopal, Madhya Pradesh. We focus on delivering responsible, unbiased, and
                        research-oriented educational content that helps individuals develop financial awareness.</p>

                    <h3>Our Purpose</h3>
                    <p>To promote financial literacy and enable individuals to understand financial markets without
                        dependency on speculative information.</p>

                    <h3>Our Vision</h3>
                    <p>To become a trusted source of financial education by supporting individuals in learning with
                        transparency, accuracy, and responsibility.</p>

                    <div class="values-grid">
                        <div class="value-item">
                            <i class="fas fa-graduation-cap"></i>
                            <h4>Financial Education & Research</h4>
                            <p>Building financial awareness through ethical education</p>
                        </div>
                        <div class="value-item">
                            <i class="fas fa-handshake"></i>
                            <h4>Integrity</h4>
                            <p>We maintain the highest standards of honesty and transparency in all our communications.
                            </p>
                        </div>
                        <div class="value-item">
                            <i class="fas fa-eye"></i>
                            <h4>Transparency</h4>
                            <p>Clear, open communication about what we do and don't provide to our clients.</p>
                        </div>
                        <div class="value-item">
                            <i class="fas fa-balance-scale"></i>
                            <h4>Accountability</h4>
                            <p>We take responsibility for the educational content we provide and its impact.</p>
                        </div>
                    </div>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
                        alt="Financial Education">
                </div>
            </div>
        </div>
    </section>

    <!-- Stock Chart Animation -->
    <!-- <div class="stock-chart">
        <div class="chart-container">
            <div class="chart-line-animated"></div>
        </div>
    </div> -->

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <h2>Services</h2>
            <p style="text-align: center; max-width: 900px; margin: 0 auto 50px;">Our educational programs are designed
                to build financial awareness without providing investment advice.</p>

            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="service-content">
                        <h3>Market Awareness Programs</h3>
                        <p>Introductory learning sessions designed to help individuals understand how financial markets
                            function, including basic concepts, structures, and market behavior.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="service-content">
                        <h3>Financial Research Insights</h3>
                        <p>General market observations created from publicly available information to support
                            awareness—not decision-making or trading.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="service-content">
                        <h3>Risk Understanding & Management</h3>
                        <p>Educational content focused on market volatility, risk exposure, and responsible financial
                            understanding. This is not personalized risk advisory.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-chart-pie"></i>
                    </div>
                    <div class="service-content">
                        <h3>Portfolio Understanding Workshops</h3>
                        <p>Awareness-based learning on diversification principles, long-term planning ideas, and
                            financial discipline. No personal portfolio guidance is provided.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <div class="service-content">
                        <h3>Educational Webinars & Seminars</h3>
                        <p>Regular sessions covering market basics, investor psychology, economic factors, and market
                            functioning.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-book"></i>
                    </div>
                    <div class="service-content">
                        <h3>Financial Literacy Resources</h3>
                        <p>Comprehensive educational materials, guides, and tools to enhance your understanding of
                            financial markets and concepts.</p>
                    </div>
                </div>
            </div>

            <div class="disclaimer-box">
                <p class="text-blue-600 font-semibold">
                    <strong>Important Notice:</strong>
                    All our offerings are strictly educational. We do not provide investment advice or trading
                    recommendations.
                    Molexi Fortuna Private Limited is not SEBI registered and does not provide investment or trading
                    advice.
                </p>
            </div>
        </div>
    </section>

    <!-- Why Choose Us Section -->
    <section id="why-choose">
        <div class="container">
            <h2>Why Choose Us</h2>
            <p style="text-align: center; max-width: 900px; margin: 0 auto 50px;">We differentiate ourselves through our
                commitment to ethical, transparent financial education.</p>

            <div class="features-grid">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="feature-text">
                        <h3>Transparent and Responsible</h3>
                        <p>We maintain complete transparency in all our communications and educational materials,
                            ensuring you receive honest information.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-ban"></i>
                    </div>
                    <div class="feature-text">
                        <h3>No Misleading Promises</h3>
                        <p>We do not make unrealistic claims or promises about financial outcomes. Our focus is solely
                            on education.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <div class="feature-text">
                        <h3>Research-Informed Content</h3>
                        <p>All our educational materials are based on thorough research and analysis, not speculation or
                            market predictions.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-award"></i>
                    </div>
                    <div class="feature-text">
                        <h3>Ethical and Compliant Approach</h3>
                        <p>We adhere to the highest ethical standards in financial education and maintain full
                            compliance with regulations.</p>
                    </div>
                </div>
            </div>

            <div class="disclaimer-box" style="margin-top: 60px;">
                <h3>What We DO NOT Provide</h3>
                <p>
                    <font color="#234545">To maintain complete transparency, we want to be clear about services we do
                        not offer.
                </p>
                <ul style="margin-top: 20px; columns: 2;">
                    <li><i class="fas fa-times-circle"></i> Stock recommendations or tips</li>
                    <li><i class="fas fa-times-circle"></i> Intraday or positional trading calls</li>
                    <li><i class="fas fa-times-circle"></i> Personalized investment advisory</li>
                    <li><i class="fas fa-times-circle"></i> Guaranteed profits or returns</li>
                    <li><i class="fas fa-times-circle"></i> SEBI-regulated advisory services</li>
                    <li><i class="fas fa-times-circle"></i> Portfolio management services</li>
                    </font>
                </ul>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <h2>Contact Us</h2>
            <p style="text-align: center; max-width: 900px; margin: 0 auto 50px;">Get in touch with us to learn more
                about our educational programs</p>

            <div class="contact-container">
                <div class="contact-info">
                    <h3>Get In Touch</h3>
                    <p>For general inquiries related to our educational and research-based offerings, contact us using
                        the details below:</p>

                    <div class="contact-item">
                        <i class="fa-solid fa-location-dot"></i>
                        <div>
                            <h4>Address</h4>
                            <p>Molexi Fortuna Private Limited
                                FF 5-B, First Floor, Mansarover Complex,
                                Shivaji Nagar (Bhopal), Huzur,<br>
                                Bhopal – 462016, Madhya Pradesh, India
                            </p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <i class="fa-solid fa-phone-volume"></i>
                        <div>
                            <h4>Phone</h4>

                            <p class="phone-line">
                                <i class="fa-solid fa-mobile-screen-button"></i>
                                +91 7771961981
                            </p>

                            <p class="phone-line">
                                <i class="fa-solid fa-phone"></i>
                                +91 7554519981
                            </p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <i class="fa-solid fa-envelope-open-text"></i>
                        <div>
                            <h4>Email</h4>
                            <p>molexifortuna@gmail.com</p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                        <div>
                            <h4>Response Time</h4>
                            <p>Our team responds within 24 working hours.</p>
                        </div>
                    </div>


                    <!-- <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                    </div> -->
                </div>

                <div class="contact-form">
                    <h3>Send us a Message</h3>
                    <form id="messageForm" action="mailto:molexifortuna@gmail.com" method="post" enctype="text/plain">
                        <input type="text" name="name" placeholder="Your Name" required>
                        <input type="email" name="email" placeholder="Your Email" required>
                        <input type="tel" name="phone" placeholder="Your Phone">
                        <select name="inquiry" required>
                            <option value="" disabled selected>Select Inquiry Type</option>
                            <option value="education">Educational Programs</option>
                            <option value="webinar">Webinar Registration</option>
                            <option value="research">Research Inquiry</option>
                            <option value="partnership">Partnership</option>
                            <option value="other">Other</option>
                        </select>
                        <textarea name="message" placeholder="Your Message" required></textarea>
                        <button type="submit" class="btn"><i class="fas fa-paper-plane"></i> Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-top">
                <img src="https://ik.imagekit.io/digirank/WhatsApp%20Image%202025-11-26%20at%206.26.43%20PM.jpeg"
                    alt="Molexi Fortuna Logo" class="footer-logo-img">
            </div>

            <div class="footer-content">
                <div class="footer-column">
                    <a href="#" class="footer-logo">Molexi Fortuna</a>
                    <p>Empowering Financial Awareness Through Research & Education. We are committed to providing
                        ethical, transparent, and research-based financial education to help individuals make informed
                        decisions.</p>
                    <p style="margin-top: 20px;"><strong><i class="fas fa-id-card"></i> CIN:</strong>
                        U66190MP2025PTC077612</p>
                </div>

                <div class="footer-column">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#home"><i class="fas fa-chevron-right"></i> Home</a></li>
                        <li><a href="#about"><i class="fas fa-chevron-right"></i> About Us</a></li>
                        <li><a href="#services"><i class="fas fa-chevron-right"></i> Services</a></li>
                        <li><a href="#why-choose"><i class="fas fa-chevron-right"></i> Why Choose Us</a></li>
                        <li><a href="#contact"><i class="fas fa-chevron-right"></i> Contact</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><i class="fas fa-map-marker-alt"></i> Bhopal, Madhya Pradesh</li>
                        <li><i class="fa fa-mobile"></i> +91 7771961981</li>
                        <li><i class="fas fa-phone"></i> +91 7554519981</li>
                        <li><i class="fas fa-envelope"></i> molexifortuna@gmail.com</li>
                        <li><i class="fas fa-clock"></i> Mon - Sat: 9:00 AM - 7:00 PM</li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h4>Legal</h4>
                    <ul>
                        <li><a href="#"><i class="fas fa-file-contract"></i> Privacy Policy</a></li>
                        <li><a href="#"><i class="fas fa-gavel"></i> Terms & Conditions</a></li>
                        <li><a href="#"><i class="fas fa-exclamation-triangle"></i> Disclaimer</a></li>
                        <li><a href="#"><i class="fas fa-shield-alt"></i> Compliance</a></li>
                    </ul>
                </div>
            </div>

            <!-- 🌐 Social Icons Added Here -->
            <div style="text-align:center; margin:25px 0 10px;">
    
    <a href="https://www.facebook.com/share/1LytNJXSGe/"
       style="color:#ffffff; font-size:28px; margin:0 12px; text-decoration:none;
              text-shadow: 1px 1px 2px rgba(0,0,0,0.6);">
        <i class="fab fa-facebook"></i>
    </a>

    <a href="https://www.instagram.com/molexifortuna?igsh=MWxzeWZvNDg4NHFzOA=="
       style="color:#ffffff; font-size:28px; margin:0 12px; text-decoration:none;
              text-shadow: 1px 1px 2px rgba(0,0,0,0.6);">
        <i class="fab fa-instagram"></i>
    </a>

    <a href="https://wa.me/917771961981?text=I%20am%20interested%20in%20your%20service%20please"
       style="color:#ffffff; font-size:28px; margin:0 12px; text-decoration:none;
              text-shadow: 1px 1px 2px rgba(0,0,0,0.6);">
        <i class="fab fa-whatsapp"></i>
    </a>

</div>

            <!-- End Social Icons -->

            <div class="copyright">
                <p>© 2025 Molexi Fortuna Private Limited. All Rights Reserved.</p>
                <p style="margin-top: 15px; font-size: 0.85rem;">
                    Molexi Fortuna Private Limited is not a SEBI-registered advisory company and does not provide
                    investment advice, stock tips, trading signals, portfolio management, or guaranteed returns. All
                    website content is strictly for educational and informational purposes only. Users are solely
                    responsible for their financial decisions.
                </p>
            </div>
        </div>
    </footer>

    <!-- FontAwesome Icons -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>

    <script>
        // Create dynamic stock market background
        function createMarketBackground() {
            const marketBg = document.getElementById('marketBg');
            const chartCount = 30;

            for (let i = 0; i < chartCount; i++) {
                const chartLine = document.createElement('div');
                chartLine.className = Math.random() > 0.5 ? 'chart-line' : 'chart-bar';

                // Random positioning
                chartLine.style.left = Math.random() * 100 + '%';
                chartLine.style.top = Math.random() * 100 + '%';

                // Random animation delay
                chartLine.style.animationDelay = Math.random() * 20 + 's';

                // Random size for bars
                if (chartLine.className === 'chart-bar') {
                    chartLine.style.height = Math.random() * 100 + 50 + 'px';
                }

                marketBg.appendChild(chartLine);
            }
        }

        // Advanced Typing Animation
        const typingText = document.getElementById('typingText');
        const texts = [
            "Empowering Financial Awareness Through Research & Education",
            "Learn with Clarity. Invest with Wisdom.",
            "Your Partner in Financial Education",
            "Building Financial Literacy for Tomorrow"
        ];
        let textIndex = 0;
        let charIndex = 0;
        let isDeleting = false;
        let typingSpeed = 100;

        function typeText() {
            const currentText = texts[textIndex];

            if (isDeleting) {
                typingText.textContent = currentText.substring(0, charIndex - 1);
                charIndex--;
                typingSpeed = 50;
            } else {
                typingText.textContent = currentText.substring(0, charIndex + 1);
                charIndex++;
                typingSpeed = 100;
            }

            if (!isDeleting && charIndex === currentText.length) {
                isDeleting = true;
                typingSpeed = 1500; // Pause at end
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
                typingSpeed = 500; // Pause before next text
            }

            setTimeout(typeText, typingSpeed);
        }

        // Animated Counter
        function animateCounter() {
            const counters = document.querySelectorAll('.counter-value');
            const speed = 200;

            counters.forEach(counter => {
                const target = +counter.getAttribute('data-count');
                const increment = target / speed;
                let current = 0;

                const updateCounter = () => {
                    if (current < target) {
                        current += increment;
                        counter.textContent = Math.ceil(current);
                        setTimeout(updateCounter, 1);
                    } else {
                        counter.textContent = target;
                    }
                };

                updateCounter();
            });
        }

        // Mobile menu toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');

        mobileMenuBtn.addEventListener('click', () => {
            mainNav.classList.toggle('active');
            mobileMenuBtn.innerHTML = mainNav.classList.contains('active')
                ? '<i class="fas fa-times"></i>'
                : '<i class="fas fa-bars"></i>';
        });

        // Close mobile menu when clicking a link
        const navLinks = document.querySelectorAll('nav a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                mainNav.classList.remove('active');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            });
        });

        // Form submission
        const messageForm = document.getElementById('messageForm');
        messageForm.addEventListener('submit', (e) => {
            // Allow form to submit to email
            setTimeout(() => {
                alert('Thank you for your message. We will get back to you soon.');
                messageForm.reset();
            }, 500);
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();

                const targetId = this.getAttribute('href');
                if (targetId === '#') return;

                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 100,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Initialize everything when page loads
        window.addEventListener('load', () => {
            createMarketBackground();
            typeText();

            // Start counter animation when in view
            const observerOptions = {
                root: null,
                rootMargin: '0px',
                threshold: 0.3
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        animateCounter();
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);

            const counterSection = document.querySelector('.counter-section');
            if (counterSection) observer.observe(counterSection);
        });

        // Add hover effect to service cards
        const serviceCards = document.querySelectorAll('.service-card');
        serviceCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-15px) scale(1.03)';
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Add parallax effect to hero section
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const hero = document.querySelector('.hero');
            if (hero) {
                hero.style.backgroundPositionY = scrolled * 0.5 + 'px';
            }
        });
    </script>
</body>

</html>